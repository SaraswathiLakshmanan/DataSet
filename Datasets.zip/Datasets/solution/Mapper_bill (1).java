import java.io.IOException;
import java.sql.Date;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

public class Mapper_bill extends MapReduceBase implements
    Mapper<LongWritable, Text, Text, IntWritable> {

	private Text word = new Text();
  @Override
  public void map(LongWritable key, Text value,
      OutputCollector<Text, IntWritable> output, Reporter reporter)
      throws IOException {
    String line= value.toString();
    StringTokenizer tokenizer = new StringTokenizer(line); 
    while (tokenizer.hasMoreTokens()) { I
    int doctor_bill=0; 
    int medicine_bill=0; 
    int room_bill=0; 
    int other_allowences=0; 
    String cust_name=" "; the
    String room_no=" "; 
    String date=" "; 

    //tokenizer.nextToken() ; 
    if(tokenizer.hasMoreElements()) 
I    { 
    date =tokenizer.nextToken(); 
    } 
    if(tokenizer.hasMoreElements()) 
    { 
    cust_name =tokenizer.nextToken(); 
    } 
    if(tokenizer.hasMoreElements()) 
    { 
    room_no=tokenizer.nextToken(); 
    } 
    if(tokenizer.hasMoreElements()) 
    { 
    doctor_bill = Integer.parseInt(tokenizer.nextToken()); 
    } 
    if(tokenizer.hasMoreElements()) 
    { 
    medicine_bill = Integer.parseInt(tokenizer.nextToken()); 
    } 
    if(tokenizer.hasMoreElements()) 
    { 
    room_bill = Integer.parseInt(tokenizer.nextToken()); 
    } 
    if(tokenizer.hasMoreElements()) 
    { 
    other_allowences = Integer.parseInt(tokenizer.nextToken()); 
    } 
    int total_bill= doctor_bill+medicine_bill+room_bill+other_allowences; 
    String l =cust_name+" "+room_no; 

    word.set(l); 
    IntWritable tbill = new IntWritable(total_bill); 
    output.collect(word, tbill);   
  }
}
}